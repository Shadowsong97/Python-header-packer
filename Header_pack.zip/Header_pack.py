#!/usr/bin/env python

import socket
import struct
import textwrap

print('processing....')


def main():
    conn = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(3))
    print('Geting resources...')

    while True:
        data,addr = conn.recvfrom(65536)
        eth_pack,eth_proto,data = packethernet_frame_pack(data)
        print('\nEthernet Frame Packed: ', eth_pack)

        if eth_proto == 8:
            ip4_pack,proto,data = ipv4_pack(data)
            print('\t-IPV4 packet Packed: ', ip4_pack)

            if proto == 1:
                icmp_packed, data = icmp_pack(data)
                print('\t-ICMP packet Packed: ', icmp_packed)

            elif proto == 6:
                tcp_seg_packed, data = tcp_seg_pack(data)
                print('\tTCP segment Packed: ',tcp_seg_packed)

            elif proto == 17:
                udp_packed = udp_segment_pack(data)
                print('\tUDP Segment Packed:', udp_packed )

            else:
                pass
        else:
            pass


def packethernet_frame_pack(data):
    dest_mac, src_mac, proto = struct.unpack('! 6s 6s H', data[:14])
    eth_pack = struct.pack('6s6sH', dest_mac, src_mac, proto)
    return eth_pack, socket.htons(proto),data[14:]

def ipv4_pack(data):
    ttl, proto, src, target = struct.unpack('! 8x B B 2x 4s 4s', data[:20])
    ip4_pack = struct.pack('8xBB2x4s4s', ttl, proto, src, target)
    return ip4_pack, proto, data[20:]

def icmp_pack(data):
    icmp_type, code, checksum = struct.unpack('! B B H', data[:4])
    icmp_packed = struct.pack('BBH', icmp_type,code,checksum)
    return icmp_packed , data[4:]

def tcp_seg_pack(data):
    src_port, dest_port, seq, ack, off_res_flag = struct.unpack('! H H L L H', data[:14])
    tcp_seg_packed = struct.pack('HHLLH', src_port, dest_port, seq, ack, off_res_flag)
    return tcp_seg_packed, data[14:]

def udp_segment_pack(data):
    src_port, dest_port, length = struct.unpack('! H H 2x H', data[:8])
    udp_packed = struct.pack('HH2xH', src_port, dest_port, length)
    return udp_packed




main()
